from django.urls import path
from .import views
from django.conf.urls.static import static
from django.conf import settings
from myapp import views #추가


urlpatterns = [
    path("", views.index, name= "index"),
    path("example/", views.example, name='example.html'),
    path("home/", views.home, name='home.html'),
    path("python/", views.python_menu, name = "python_menu.html"),
    path("spring/", views.spring, name = "spring.html"),
    path("TermsIF/",views.TermsIF, name='TermsIF.html'),
    path("TermsFor/",views.TermsFor, name='TermsFor.html'),
    
    #장고
    path("django/",views.django_menu, name='django_menu.html'),
    
    #스킬
    path("skill/", views.skill, name = "skill.html"),
    
    #DB
    path("db_menu/",views.db_menu, name='db_menu.html'),
    path("db_base/",views.db_base, name='db_base.html'),
    path("new/", views.new_topic, name ='new_topic'),
    path('edit_topic/<int:topic_id>/', views.edit_topic, name='edit_topic'),
    path('delete_topic/<int:topic_id>/', views.delete_topic, name='delete_topic'),
    path('todolist/', views.todo_list, name='todo_list'),
    
    
    
    
    
    
    
]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)