#장고의 view를 html문법으로 바꾸기 위한 렌더링모듈과 new_topic view db_menu으로 돌아가기 위한 redirect모듈 
from django.shortcuts import render, redirect, get_object_or_404
#모델의 클래스명
from .models import Topic, Reply, Task

#http 상태를 나타내기 위한 장고모듈 
from django.http import HttpResponse
from django.contrib.auth.models import User
#장고의 사용자 모듈

# Create your views here.

def index(request):    
    return HttpResponse("Hello")


def example(request):
    return render(request, 'example.html')

def home(request):
    return render(request, 'home.html')

def python_menu(request):
    return render(request, 'menu_list/python_menu.html')

#파이썬 내용
def spring(request):
    return render(request, 'menu_list/python_sidemenu/spring.html')

def TermsIF(request):
    return render(request, 'menu_list/python_sidemenu/TermsIF.html')

def TermsFor(request):
    return render(request, 'menu_list/python_sidemenu/TermsFor.html')


#장고
def django_menu(request):
    return render(request, 'menu_list/django_sidemenu/django_menu.html')



#스킬

def skill(request):
    return render(request, 'skill.html')





#게시판
def db_menu(request):
    topics = Topic.objects.all() #model의 Topic 개체 생성
    return render(request,'menu_list/db_menu.html',{'topics':topics})


def db_base(request):
    return render(request, 'menu_list/db_base.html')

def new_topic(request):

    topics = Topic.objects.all()
    if request.method =='POST':
        subject = request.POST['subject']
        message = request.POST['message']

        user = User.objects.first()

        topic = Topic.objects.create(
            subject=subject,
            message=message,
            writter=user
        )

        post = Reply.objects.create(
            message=message,
            created_by=user
        )
        return redirect('db_menu.html')
    return render(request,'menu_list/new_topic.html',{'topics':topics})



#수정하기 
def edit_topic(request, topic_id):
    topic = get_object_or_404(Topic, id=topic_id)

    if request.method == 'POST':
        # 폼에서 제출된 데이터로 게시글을 수정
        topic.subject = request.POST['subject']
        topic.message = request.POST['message']
        topic.save()
        return redirect('db_menu.html')  # 수정 완료 후 db_menu 페이지로 리다이렉트

    return render(request, 'menu_list/edit_topic.html', {'topic': topic})


def delete_topic(request, topic_id):
    topic = get_object_or_404(Topic, id=topic_id)
    topic.delete()
    return redirect('db_menu.html')  # 삭제 완료 후 db_menu 페이지로 리다이렉트


#to-do-list
def todo_list(request):
    tasks = Task.objects.all()
    return render(request, 'to-do_list/todo_list.html', {'tasks':tasks})