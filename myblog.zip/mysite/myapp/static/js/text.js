


// 결과 출력
console.log(trimmedText);
