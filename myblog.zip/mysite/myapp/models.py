from django.db import models

from django.contrib.auth.models import User

class Topic(models.Model):
    message = models.TextField(max_length=5000,null=True)
    # 글 내용을 저장하는 필드 TextFiedl(타입)로 정의가 되어있고, 최대 길이는 5000자.
    # null= True : 데이터 베이스에 저장될 때 null 값을 허용한다.
    # → 해당 필드가 비어있어도 데이터베이스에 저장이 가능하다.
    
    subject = models.CharField(max_length=255)
    #글의 제목을 저장하는 필드
    
    last_updated =  models.DateField(auto_now_add=True, null=True)
    #글이 마지막으로 업데이트가 된 날짜로 저장하는 필드
    #auto_now_add=True : 해당 모델의 인스턴스가 처음 생성될 때 자동으로 할당
    
    writter = models.ForeignKey(User, related_name='topics',
                                on_delete=models.CASCADE, null=True)
    # 주제를 작성한 사용자를 나타내는 외래키 필드
    # 사용자 모델과의 관계를 맺고, 한 사용자가 여러 주제를 작성할 수 있다.


class Reply(models.Model):
    message = models.TextField(max_length=5000)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by= models.ForeignKey(User, null=True, related_name='posts',on_delete=models.CASCADE)
    updated_at = models.DateField(null = True)
    updated_by=  models.ForeignKey(User,null=True,related_name='+',on_delete=models.CASCADE)
    
    
# to-do-list
class Task(models.Model):
    title = models.CharField(max_length=200)
    
    #list의 제목
    description = models.TextField()
    
    #완료여부
    completed = models.BooleanField(default=False)
    
    #생성일
    created_at = models.DateTimeField(auto_now_add=True)
    #auto_now_add=True : 자동으로 현재 날짜와 시간으로 설정
    